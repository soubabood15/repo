#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'
$taskName = 'NewtelUcmQueueConnector'
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
$action = @($task.Actions)[0]
$project = $action.WorkingDirectory
if (-not $project -or -not (Test-Path -LiteralPath (Join-Path $project 'connector\ucm-queue-connector.mjs'))) {
    if ($action.Arguments -match '-ProjectPath\s+"([^"]+)"') { $project = $Matches[1] }
}
if (-not $project -or -not (Test-Path -LiteralPath (Join-Path $project 'connector\ucm-queue-connector.mjs'))) { throw 'Installed connector folder not found. No changes made.' }
$target = Join-Path $project 'connector'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'hashes.json') -Raw | ConvertFrom-Json
foreach ($file in $manifest.PSObject.Properties) {
    $source = Join-Path (Join-Path $PSScriptRoot 'connector') $file.Name
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $file.Value) { throw 'Update file verification failed. No changes made.' }
}
$backup = Join-Path $env:ProgramData ('Newtel\UcmConnector\quality-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($file in $manifest.PSObject.Properties) {
    $existing = Join-Path $target $file.Name
    if (Test-Path -LiteralPath $existing) { Copy-Item -LiteralPath $existing -Destination (Join-Path $backup $file.Name) }
}
Stop-ScheduledTask -TaskName $taskName
Start-Sleep -Seconds 3
try {
    foreach ($file in $manifest.PSObject.Properties) { Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'connector') $file.Name) -Destination (Join-Path $target $file.Name) -Force }
} catch {
    foreach ($file in $manifest.PSObject.Properties) {
        $old = Join-Path $backup $file.Name
        if (Test-Path -LiteralPath $old) { Copy-Item -LiteralPath $old -Destination (Join-Path $target $file.Name) -Force }
        else { Remove-Item -LiteralPath (Join-Path $target $file.Name) -ErrorAction SilentlyContinue }
    }
    throw
} finally { Start-ScheduledTask -TaskName $taskName }
Write-Host 'Quality audio streaming update v2 installed. Credentials and queued attendance were preserved.'
Write-Host 'Go back to Quality, link the call, then choose Play recording.'
