NEWTEL Quality Audio Update

On the Windows computer running the installed UCM connector:
1. Extract all files.
2. Run UPDATE.bat and accept the administrator prompt.
3. Refresh Quality, link a UCM call and press Play recording.

Uses existing API credentials and certificate verification. No recording files are written to disk by the connector. Audio is streamed through an in-memory relay; D1 and R2 are not used for audio.
Only WAV recordings are supported; encrypted recordings require a separate integration.
