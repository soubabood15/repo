@echo off
powershell.exe -NoLogo -NoProfile -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList '-NoLogo -NoProfile -ExecutionPolicy Bypass -File ""%~dp0UPDATE.ps1""'"
pause
