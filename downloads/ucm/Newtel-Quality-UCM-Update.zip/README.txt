On the Windows computer running the installed Newtel UCM connector:
1. Extract all files.
2. Run UPDATE.bat and accept the Windows administrator prompt.
3. Reopen Link UCM call in Quality.
This update uses the existing connector settings and only requests call metadata when Quality asks for it.
Backup files are kept in ProgramData/Newtel/UcmConnector.
